# SAVE_MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_V1.ps1
# Local-only mule handoff placement. No Git. No push. No public export.

$ErrorActionPreference = "Stop"

$Stamp = Get-Date -Format "yyyyMMdd_HHmmss"
$Root = Join-Path $env:USERPROFILE "Desktop\ASSISTANT_LOCAL"
$MuleRoot = Join-Path $Root "MULE_REVIEW"
$Returns = Join-Path $MuleRoot "RETURNS"
$ReceiptDir = Join-Path $Root "_RECEIPTS"
$Desktop = Join-Path $env:USERPROFILE "Desktop"

New-Item -ItemType Directory -Path $MuleRoot,$Returns,$ReceiptDir -Force | Out-Null

$HandoffPath = Join-Path $MuleRoot "MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_V1.md"
$KickoffPath = Join-Path $MuleRoot "MULE_KICKOFF_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md"
$DesktopKickoff = Join-Path $Desktop "MULE_HANDOFF_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md"
$ReceiptPath = Join-Path $ReceiptDir ("MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_RECEIPT_{0}.txt" -f $Stamp)

$Handoff = @'
# MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_V1

STATUS: MULE REVIEW HANDOFF / LOCAL-ONLY / REVIEW BEFORE FIX

PURPOSE:
Give the mule a clear review job for the assistant-local stabilization work, including the broad packet already created:
`ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`

The mule’s job is to deep-review the assistant’s work, find real problems, avoid ghost issues, explain all real issues broadly, and propose clean solutions that fit the house/edit rules.

BOUNDARY:
- Local-only review support.
- No Git.
- No push.
- No public export.
- No doctrine promotion.
- No ACTIVE_GUIDES rewrite.
- No CURRENT_TRUTH_INDEX rewrite.
- No deletion.
- No broad cleanup.
- No automatic merge.
- No final authority claim.
- Do not treat this handoff or the broad packet as doctrine.
- Do not treat memory as proof.

ACTIVE REVIEW TARGETS:
1. `ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
2. The actual-plate workflow candidate that started from:
   - parking ledger needed;
   - data logs lane needed;
   - gap backfill needed;
   - Base Project Chat rule local save needed;
   - ASSISTANT_LOCAL index needed;
   - invalid receipt quarantine needed;
   - daily/session logging trigger needed.
3. Current assistant-local root:
   `C:\Users\13527\Desktop\ASSISTANT_LOCAL`
4. Current visible Desktop chat drop-copies:
   `CHAT_DROP_COPY__...`

WHERE TO LOOK FOR THE BROAD PACKET:
Search these locations only. Do not broad-crawl the PC.

1. `C:\Users\13527\Downloads\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
2. `C:\Users\13527\Desktop\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
3. `C:\Users\13527\Desktop\123\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
4. `C:\Users\13527\Desktop\ASSISTANT_LOCAL\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
5. `C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`

IF THE BROAD PACKET IS MISSING:
Stop and write:
`BLOCKED / SOURCE PACKET MISSING`

Do not guess its content.
Do not proceed from memory.
Request the user place/download the file first.

WHERE THIS HANDOFF SHOULD LIVE:
Preferred local home:
`C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW`

Visible short pickup copy may also be placed on Desktop:
`MULE_HANDOFF_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md`

MULE MODE:
Deep review once, then produce one clean return file.
Do not keep looping.
Do not do broad unrelated cleanup.
Do not add systems just because they sound useful.

REVIEW METHOD:
Use the house/edit procedure:

1. Read the kickoff.
2. Locate the broad packet.
3. Confirm boundary.
4. Read the broad packet once for structure.
5. Read it again as an editor/reviewer.
6. Build a real issue list.
7. Filter ghost issues.
8. Group issues by lane.
9. Explain each real issue broadly.
10. Propose minimal clean fixes.
11. Identify what should be saved locally.
12. Identify what should remain only candidate.
13. Identify what needs user approval before action.
14. Write one return file.

REQUIRED TOOLS / RESOURCES:
Use available local files, receipts, and paths before claims.
Use the broad packet as source material.
Use existing local receipts where visible.
Use only targeted folders:
- `C:\Users\13527\Desktop\ASSISTANT_LOCAL`
- `C:\Users\13527\Desktop`
- `C:\Users\13527\Desktop\123`
- `C:\Users\13527\Downloads`

Do not use broad crawling.
Do not inspect unrelated folders.
Do not rely only on memory.

REAL ISSUE CRITERIA:
A real issue must have at least one:
- observed failure;
- missing file;
- missing receipt;
- invalid proof;
- broken delivery surface;
- current blocker;
- user correction;
- unresolved parked item;
- lane mismatch;
- boundary mismatch;
- repeated failure pattern;
- explicit source packet weakness.

GHOST ISSUE FILTER:
Do not add an issue if it is only:
- hypothetical;
- broad anxiety;
- old payload carried into a new lane;
- unnecessary dashboard/database/automation;
- solution looking for a problem;
- doctrine rewrite without authorization;
- Git/public expansion without authorization.

REVIEW LANES:
Group findings under these headings:

A. Parking and custody.
B. Data logs and session logging.
C. Gap backfill.
D. Assistant-local index.
E. Invalid receipts and proof hygiene.
F. Chat rules and new-chat pickup.
G. Review surfaces: House Chat / Base Project Chat / Clean-Room Chat.
H. Tool/resource use.
I. Delivery surface and PowerShell/file shape.
J. Burning notes and scratch custody.
K. Memory vs proof.
L. Local-only vs Git/public boundary.
M. Minimal next implementation.
N. Blocked or user-approval-needed items.
O. Ghost issues rejected.

REQUIRED OUTPUT FILE:
Create exactly one return file:

`MULE_RETURN_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md`

Recommended local return folder:
`C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW\RETURNS`

TOP BLOCK REQUIRED:
STATUS:
RUN LOCK:
FILES READ:
SOURCE PACKET FOUND:
TASK:
SCOPE:
MODE:
NOT DONE:
NEEDS USER REVIEW:

RETURN BODY REQUIRED:
1. Executive verdict.
2. Files found/read.
3. Real issues found.
4. Ghost issues rejected.
5. Broad explanations.
6. Minimal clean fixes.
7. Suggested local file set.
8. What not to do.
9. What needs user approval.
10. Next clean action.
11. Final Judge.

FINAL JUDGE:
Before returning, check:
- Did the mule locate the broad packet?
- Did the mule use source files instead of guessing?
- Did the mule stay local-only?
- Did the mule avoid Git/public/doctrine?
- Did the mule distinguish real issues from ghost issues?
- Did the mule give broad explanations but minimal fixes?
- Did the mule create only the requested return file?
- Did the mule clearly mark blocked or approval-needed items?

STOP RULE:
Stop after one return file or one BLOCKED source-missing note.

'@

$Kickoff = @'
# MULE_KICKOFF_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1

STATUS: SHORT MULE KICKOFF

Mule task:
Review the assistant-local stabilization work.

Find and read:
`ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`

Look only in:
1. `C:\Users\13527\Downloads`
2. `C:\Users\13527\Desktop`
3. `C:\Users\13527\Desktop\123`
4. `C:\Users\13527\Desktop\ASSISTANT_LOCAL`
5. `C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW`

If the broad packet is missing, stop with:
`BLOCKED / SOURCE PACKET MISSING`

Do not guess.

Use:
`MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_V1.md`

Output one file:
`MULE_RETURN_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md`

Return folder:
`C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW\RETURNS`

Boundary:
local-only, no Git, no push, no public, no doctrine, no ACTIVE_GUIDES rewrite, no CURRENT_TRUTH_INDEX rewrite, no deletion, no broad cleanup.

Review job:
deep dive once, make the real issue list, reject ghost issues, explain broadly, propose minimal clean fixes, and follow edit/house rules.

Required top block:
STATUS:
RUN LOCK:
FILES READ:
SOURCE PACKET FOUND:
TASK:
SCOPE:
MODE:
NOT DONE:
NEEDS USER REVIEW:

'@

Set-Content -LiteralPath $HandoffPath -Value $Handoff -Encoding UTF8
Set-Content -LiteralPath $KickoffPath -Value $Kickoff -Encoding UTF8
Copy-Item -LiteralPath $KickoffPath -Destination $DesktopKickoff -Force

$BroadPacketName = "ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md"
$SearchRoots = @(
    (Join-Path $env:USERPROFILE "Downloads"),
    (Join-Path $env:USERPROFILE "Desktop"),
    (Join-Path $env:USERPROFILE "Desktop\123"),
    (Join-Path $env:USERPROFILE "Desktop\ASSISTANT_LOCAL"),
    $MuleRoot
)

$FoundBroadPacket = $null
foreach ($SearchRoot in $SearchRoots) {
    if (Test-Path -LiteralPath $SearchRoot) {
        $Candidate = Get-ChildItem -LiteralPath $SearchRoot -Filter $BroadPacketName -File -ErrorAction SilentlyContinue | Sort-Object LastWriteTime -Descending | Select-Object -First 1
        if ($Candidate) {
            $FoundBroadPacket = $Candidate.FullName
            break
        }
    }
}

$PacketStatus = "NOT FOUND - MULE MUST STOP UNTIL USER PLACES/DOWNLOADS SOURCE PACKET"
$PacketHash = ""
if ($FoundBroadPacket) {
    $PacketHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $FoundBroadPacket).Hash
    $PacketStatus = "FOUND: $FoundBroadPacket"
}

$HandoffHash = Get-FileHash -Algorithm SHA256 -LiteralPath $HandoffPath
$KickoffHash = Get-FileHash -Algorithm SHA256 -LiteralPath $KickoffPath
$DesktopKickoffHash = Get-FileHash -Algorithm SHA256 -LiteralPath $DesktopKickoff

$Receipt = @"
MULE REVIEW ASSISTANT LOCAL STABILIZATION HANDOFF RECEIPT
Timestamp: $Stamp
Verdict: PASS / MULE REVIEW HANDOFF PLACED / NO GIT / NO PUSH

Placed:
- $HandoffPath
  SHA256: $($HandoffHash.Hash)

- $KickoffPath
  SHA256: $($KickoffHash.Hash)

Desktop pickup:
- $DesktopKickoff
  SHA256: $($DesktopKickoffHash.Hash)

Broad packet lookup:
- $PacketStatus
- SHA256: $PacketHash

Boundary:
- Local-only mule review support.
- No Git commit.
- No push.
- No public export.
- No doctrine promotion.
- No ACTIVE_GUIDES rewrite.
- No CURRENT_TRUTH_INDEX rewrite.
- No deletion.
- No broad cleanup.

Note:
If the broad packet is not found, mule must stop with BLOCKED / SOURCE PACKET MISSING.
"@

Set-Content -LiteralPath $ReceiptPath -Value $Receipt -Encoding UTF8

if (-not (Test-Path -LiteralPath $HandoffPath)) { throw "BLOCKED: handoff not created." }
if (-not (Test-Path -LiteralPath $KickoffPath)) { throw "BLOCKED: kickoff not created." }
if (-not (Test-Path -LiteralPath $DesktopKickoff)) { throw "BLOCKED: Desktop pickup not created." }
if (-not (Test-Path -LiteralPath $ReceiptPath)) { throw "BLOCKED: receipt not created." }

Write-Host "MULE REVIEW HANDOFF PLACED"
Write-Host "Handoff: $HandoffPath"
Write-Host "Kickoff: $KickoffPath"
Write-Host "Desktop pickup: $DesktopKickoff"
Write-Host "Broad packet: $PacketStatus"
Write-Host "Receipt: $ReceiptPath"
Write-Host "Verdict: PASS / MULE HANDOFF PLACED / NO GIT / NO PUSH"
