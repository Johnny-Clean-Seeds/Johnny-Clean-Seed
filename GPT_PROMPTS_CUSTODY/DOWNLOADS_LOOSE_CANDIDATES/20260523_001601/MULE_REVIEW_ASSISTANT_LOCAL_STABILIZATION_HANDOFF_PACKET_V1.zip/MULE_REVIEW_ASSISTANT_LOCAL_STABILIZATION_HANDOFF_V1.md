# MULE_REVIEW_ASSISTANT_LOCAL_STABILIZATION_HANDOFF_V1

STATUS: MULE REVIEW HANDOFF / LOCAL-ONLY / REVIEW BEFORE FIX

PURPOSE:
Give the mule a clear review job for the assistant-local stabilization work, including the broad packet already created:
`ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`

The mule’s job is to deep-review the assistant’s work, find real problems, avoid ghost issues, explain all real issues broadly, and propose clean solutions that fit the house/edit rules.

BOUNDARY:
- Local-only review support.
- No Git.
- No push.
- No public export.
- No doctrine promotion.
- No ACTIVE_GUIDES rewrite.
- No CURRENT_TRUTH_INDEX rewrite.
- No deletion.
- No broad cleanup.
- No automatic merge.
- No final authority claim.
- Do not treat this handoff or the broad packet as doctrine.
- Do not treat memory as proof.

ACTIVE REVIEW TARGETS:
1. `ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
2. The actual-plate workflow candidate that started from:
   - parking ledger needed;
   - data logs lane needed;
   - gap backfill needed;
   - Base Project Chat rule local save needed;
   - ASSISTANT_LOCAL index needed;
   - invalid receipt quarantine needed;
   - daily/session logging trigger needed.
3. Current assistant-local root:
   `C:\Users\13527\Desktop\ASSISTANT_LOCAL`
4. Current visible Desktop chat drop-copies:
   `CHAT_DROP_COPY__...`

WHERE TO LOOK FOR THE BROAD PACKET:
Search these locations only. Do not broad-crawl the PC.

1. `C:\Users\13527\Downloads\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
2. `C:\Users\13527\Desktop\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
3. `C:\Users\13527\Desktop\123\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
4. `C:\Users\13527\Desktop\ASSISTANT_LOCAL\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`
5. `C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW\ASSISTANT_LOCAL_BROAD_STABILIZATION_PACKET_V1.5.md`

IF THE BROAD PACKET IS MISSING:
Stop and write:
`BLOCKED / SOURCE PACKET MISSING`

Do not guess its content.
Do not proceed from memory.
Request the user place/download the file first.

WHERE THIS HANDOFF SHOULD LIVE:
Preferred local home:
`C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW`

Visible short pickup copy may also be placed on Desktop:
`MULE_HANDOFF_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md`

MULE MODE:
Deep review once, then produce one clean return file.
Do not keep looping.
Do not do broad unrelated cleanup.
Do not add systems just because they sound useful.

REVIEW METHOD:
Use the house/edit procedure:

1. Read the kickoff.
2. Locate the broad packet.
3. Confirm boundary.
4. Read the broad packet once for structure.
5. Read it again as an editor/reviewer.
6. Build a real issue list.
7. Filter ghost issues.
8. Group issues by lane.
9. Explain each real issue broadly.
10. Propose minimal clean fixes.
11. Identify what should be saved locally.
12. Identify what should remain only candidate.
13. Identify what needs user approval before action.
14. Write one return file.

REQUIRED TOOLS / RESOURCES:
Use available local files, receipts, and paths before claims.
Use the broad packet as source material.
Use existing local receipts where visible.
Use only targeted folders:
- `C:\Users\13527\Desktop\ASSISTANT_LOCAL`
- `C:\Users\13527\Desktop`
- `C:\Users\13527\Desktop\123`
- `C:\Users\13527\Downloads`

Do not use broad crawling.
Do not inspect unrelated folders.
Do not rely only on memory.

REAL ISSUE CRITERIA:
A real issue must have at least one:
- observed failure;
- missing file;
- missing receipt;
- invalid proof;
- broken delivery surface;
- current blocker;
- user correction;
- unresolved parked item;
- lane mismatch;
- boundary mismatch;
- repeated failure pattern;
- explicit source packet weakness.

GHOST ISSUE FILTER:
Do not add an issue if it is only:
- hypothetical;
- broad anxiety;
- old payload carried into a new lane;
- unnecessary dashboard/database/automation;
- solution looking for a problem;
- doctrine rewrite without authorization;
- Git/public expansion without authorization.

REVIEW LANES:
Group findings under these headings:

A. Parking and custody.
B. Data logs and session logging.
C. Gap backfill.
D. Assistant-local index.
E. Invalid receipts and proof hygiene.
F. Chat rules and new-chat pickup.
G. Review surfaces: House Chat / Base Project Chat / Clean-Room Chat.
H. Tool/resource use.
I. Delivery surface and PowerShell/file shape.
J. Burning notes and scratch custody.
K. Memory vs proof.
L. Local-only vs Git/public boundary.
M. Minimal next implementation.
N. Blocked or user-approval-needed items.
O. Ghost issues rejected.

REQUIRED OUTPUT FILE:
Create exactly one return file:

`MULE_RETURN_ASSISTANT_LOCAL_STABILIZATION_REVIEW_V1.md`

Recommended local return folder:
`C:\Users\13527\Desktop\ASSISTANT_LOCAL\MULE_REVIEW\RETURNS`

TOP BLOCK REQUIRED:
STATUS:
RUN LOCK:
FILES READ:
SOURCE PACKET FOUND:
TASK:
SCOPE:
MODE:
NOT DONE:
NEEDS USER REVIEW:

RETURN BODY REQUIRED:
1. Executive verdict.
2. Files found/read.
3. Real issues found.
4. Ghost issues rejected.
5. Broad explanations.
6. Minimal clean fixes.
7. Suggested local file set.
8. What not to do.
9. What needs user approval.
10. Next clean action.
11. Final Judge.

FINAL JUDGE:
Before returning, check:
- Did the mule locate the broad packet?
- Did the mule use source files instead of guessing?
- Did the mule stay local-only?
- Did the mule avoid Git/public/doctrine?
- Did the mule distinguish real issues from ghost issues?
- Did the mule give broad explanations but minimal fixes?
- Did the mule create only the requested return file?
- Did the mule clearly mark blocked or approval-needed items?

STOP RULE:
Stop after one return file or one BLOCKED source-missing note.
