@echo off
setlocal EnableExtensions
title Setup RoboCop Root

set "SRC=%~dp0RoboCop_Root_Template"
set "ROOT=C:\RoboCop"

if not exist "%SRC%\" (
  echo TEMPLATE FOLDER NOT FOUND:
  echo %SRC%
  echo.
  pause
  exit /b 1
)

mkdir "%ROOT%" >nul 2>nul
mkdir "%ROOT%\Back Tool" >nul 2>nul
mkdir "%ROOT%\Robo Tools" >nul 2>nul

xcopy "%SRC%\*" "%ROOT%\" /E /I /Y >nul

echo.
echo ROBOCOP ROOT SETUP COMPLETE
echo.
echo Opened:
echo C:\RoboCop
echo.
start "" "%ROOT%"
pause
