SETUP_ROBOCOP_ROOT.cmd

WHAT IT IS:
This installs the RoboCop backup tools into C:\RoboCop.

HOW TO USE:
1. Double-click SETUP_ROBOCOP_ROOT.cmd.
2. Wait for ROBOCOP ROOT SETUP COMPLETE.
3. Use the tools inside C:\RoboCop.

NEXT TOOL TO USE:
C:\RoboCop\Back Tool\BACKUP_MR_KLEEN_TO_ROBOCOP.cmd

SUCCESS:
You see ROBOCOP ROOT SETUP COMPLETE and C:\RoboCop opens.

FAILURE:
If it says TEMPLATE FOLDER NOT FOUND, keep SETUP_ROBOCOP_ROOT.cmd next to the RoboCop_Root_Template folder.
