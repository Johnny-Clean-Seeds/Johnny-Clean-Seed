ROBOCOP ROOT

WHAT IT IS:
C:\RoboCop is the backup root.

HOW TO USE:
1. Open C:\RoboCop\Back Tool.
2. Double-click BACKUP_MR_KLEEN_TO_ROBOCOP.cmd.
3. Wait for BACKUP COPY OK.

VERSION FOLDERS:
RoboCop 1
RoboCop 1.1
RoboCop 1.2
...
RoboCop 1.9
RoboCop 2.0
RoboCop 2.1

MAIN TOOLS:
Back Tool\BACKUP_MR_KLEEN_TO_ROBOCOP.cmd
Back Tool\DRAG_FOLDER_TO_ROBOCOP.cmd

SUCCESS:
A new version folder appears inside C:\RoboCop.

FAILURE:
If a tool says BACKUP FAILED, paste the bottom error block into chat.
