@echo off
setlocal EnableExtensions
title Drag Folder Backup to RoboCop

if "%~1"=="" (
  echo DRAG A FOLDER ONTO THIS FILE.
  echo.
  pause
  exit /b 1
)

set "SRC=%~1"
set "SEL=%~dp0..\Robo Tools\ROBOCOP_VERSION_SELECTOR.ps1"

if not exist "%SRC%\" (
  echo NOT A FOLDER OR SOURCE NOT FOUND:
  echo %SRC%
  echo.
  pause
  exit /b 1
)

if not exist "%SEL%" (
  echo VERSION SELECTOR NOT FOUND:
  echo %SEL%
  echo.
  pause
  exit /b 1
)

powershell -NoProfile -ExecutionPolicy Bypass -File "%SEL%"
if errorlevel 1 (
  echo FAILED TO CHOOSE NEXT ROBOCOP VERSION FOLDER.
  echo.
  pause
  exit /b 1
)

set /p DST=<"%TEMP%\ROBOCOP_NEXT_BACKUP_FOLDER.txt"
mkdir "%DST%" >nul 2>nul

echo.
echo ROBOCOP DRAG-FOLDER BACKUP
echo Source:
echo   %SRC%
echo Destination:
echo   %DST%
echo.

robocopy "\\?\%SRC%" "\\?\%DST%" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ /MT:8 /TEE /LOG:"%DST%\ROBOCOPY_BACKUP_LOG.txt"

set "CODE=%ERRORLEVEL%"

echo.
if %CODE% LEQ 7 (
  echo BACKUP COPY OK
  echo Destination: %DST%
  echo Robocopy exit code: %CODE%
  echo Log: %DST%\ROBOCOPY_BACKUP_LOG.txt
) else (
  echo BACKUP FAILED
  echo Robocopy exit code: %CODE%
  echo Check log:
  echo %DST%\ROBOCOPY_BACKUP_LOG.txt
)

echo.
pause
exit /b %CODE%
