BACKUP_MR_KLEEN_TO_ROBOCOP.cmd

WHAT IT IS:
Backs up the Mr.Kleen project folder.

SOURCE:
C:\Users\<you>\Desktop\Jxhnny_Kleen_C3dz

DESTINATION:
C:\RoboCop\RoboCop <next version>

HOW TO USE:
1. Double-click BACKUP_MR_KLEEN_TO_ROBOCOP.cmd.
2. Wait for the copy to finish.
3. Look for BACKUP COPY OK.

SUCCESS:
A new folder appears in C:\RoboCop.
Example: C:\RoboCop\RoboCop 1.2

FAILURE:
If it says BACKUP FAILED, paste the bottom error block into chat.

DO NOT:
Do not use File Explorer drag-copy for the main project backup.
Use this tool.
