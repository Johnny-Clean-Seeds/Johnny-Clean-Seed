DRAG_FOLDER_TO_ROBOCOP.cmd

WHAT IT IS:
Backs up any folder you drag onto it.

DESTINATION:
C:\RoboCop\RoboCop <next version>

HOW TO USE:
1. Find the folder you want to back up.
2. Drag that folder onto DRAG_FOLDER_TO_ROBOCOP.cmd.
3. Wait for BACKUP COPY OK.

SUCCESS:
A new folder appears in C:\RoboCop.

FAILURE:
If it says BACKUP FAILED, paste the bottom error block into chat.

DO NOT:
Do not drag loose files.
Drag a folder only.
