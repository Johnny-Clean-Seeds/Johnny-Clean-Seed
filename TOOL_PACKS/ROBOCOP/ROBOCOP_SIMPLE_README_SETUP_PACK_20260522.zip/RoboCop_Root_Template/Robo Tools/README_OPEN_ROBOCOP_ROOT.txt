OPEN_ROBOCOP_ROOT.cmd

WHAT IT IS:
Opens C:\RoboCop.

HOW TO USE:
1. Double-click OPEN_ROBOCOP_ROOT.cmd.
2. C:\RoboCop opens.
3. Check your backup folders.

SUCCESS:
File Explorer opens C:\RoboCop.

FAILURE:
If nothing opens, open C:\RoboCop manually.
