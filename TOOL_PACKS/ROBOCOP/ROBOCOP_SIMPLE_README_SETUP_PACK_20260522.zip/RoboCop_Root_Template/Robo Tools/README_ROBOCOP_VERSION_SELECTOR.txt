ROBOCOP_VERSION_SELECTOR.ps1

WHAT IT IS:
Chooses the next RoboCop version folder.

HOW TO USE:
1. Do not run this manually.
2. Leave it in C:\RoboCop\Robo Tools.
3. The backup tools use it automatically.

VERSION ORDER:
RoboCop 1
RoboCop 1.1
RoboCop 1.2
...
RoboCop 1.9
RoboCop 2.0
RoboCop 2.1

SUCCESS:
The backup tool gets a destination folder.

FAILURE:
If a backup says VERSION SELECTOR NOT FOUND, this file is missing or moved.
