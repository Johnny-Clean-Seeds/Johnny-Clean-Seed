CHECK_LONG_PATHS_SETTING.cmd

WHAT IT IS:
Checks Windows long-path support.

HOW TO USE:
1. Double-click CHECK_LONG_PATHS_SETTING.cmd.
2. Read the result.
3. Close the window.

GOOD RESULT:
LongPathsEnabled=1 OK

BAD RESULT:
LongPathsEnabled=0 WARNING should be 1

IF BAD:
Tell chat. Do not guess.
