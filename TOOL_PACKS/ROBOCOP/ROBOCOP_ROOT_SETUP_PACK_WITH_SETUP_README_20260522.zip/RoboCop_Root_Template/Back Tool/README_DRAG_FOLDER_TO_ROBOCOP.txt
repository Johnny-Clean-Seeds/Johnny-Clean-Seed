README — DRAG_FOLDER_TO_ROBOCOP.cmd

Purpose:
Back up any folder you drag onto this command file.

How to use:
Drag one folder onto:
DRAG_FOLDER_TO_ROBOCOP.cmd

Destination root:
C:\RoboCop

Each drag creates the next version folder:
C:\RoboCop\RoboCop 1
C:\RoboCop\RoboCop 1.1
C:\RoboCop\RoboCop 1.2
...
C:\RoboCop\RoboCop 1.9
C:\RoboCop\RoboCop 2.0
C:\RoboCop\RoboCop 2.1

Good result:
BACKUP COPY OK

Failure result:
BACKUP FAILED

Important:
Drag a folder, not a loose file.

Safety:
Copy only.
No delete.
No move.
No commit.
No push.
No project rewrite.
