README — BACKUP_MR_KLEEN_TO_ROBOCOP.cmd

Purpose:
Back up the main Mr.Kleen project folder into the next RoboCop version folder.

Source copied:
C:\Users\<you>\Desktop\Jxhnny_Kleen_C3dz

Destination root:
C:\RoboCop

Version pattern:
C:\RoboCop\RoboCop 1
C:\RoboCop\RoboCop 1.1
C:\RoboCop\RoboCop 1.2
...
C:\RoboCop\RoboCop 1.9
C:\RoboCop\RoboCop 2.0
C:\RoboCop\RoboCop 2.1

How to use:
Double-click:
BACKUP_MR_KLEEN_TO_ROBOCOP.cmd

Good result:
BACKUP COPY OK

Failure result:
BACKUP FAILED

If it fails:
Do not delete anything yet.
Paste the bottom error block and robocopy exit code into chat.

Safety:
Copy only.
No delete.
No move.
No commit.
No push.
No project rewrite.
