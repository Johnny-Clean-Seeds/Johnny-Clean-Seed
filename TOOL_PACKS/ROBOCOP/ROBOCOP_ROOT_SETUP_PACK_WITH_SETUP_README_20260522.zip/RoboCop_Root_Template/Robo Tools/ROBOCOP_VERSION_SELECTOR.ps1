$ErrorActionPreference = 'Stop'

$Root = 'C:\RoboCop'
New-Item -ItemType Directory -Force -Path $Root | Out-Null

$Versions = @()

Get-ChildItem -LiteralPath $Root -Directory -ErrorAction SilentlyContinue | ForEach-Object {
    if ($_.Name -eq 'RoboCop 1') {
        $Versions += [pscustomobject]@{
            Name = $_.Name
            Major = 1
            Minor = -1
        }
    }
    elseif ($_.Name -match '^RoboCop (\d+)\.(\d+)$') {
        $Versions += [pscustomobject]@{
            Name = $_.Name
            Major = [int]$Matches[1]
            Minor = [int]$Matches[2]
        }
    }
}

if ($Versions.Count -eq 0) {
    $NextName = 'RoboCop 1'
}
else {
    $Top = $Versions | Sort-Object Major, Minor -Descending | Select-Object -First 1

    if ($Top.Major -eq 1 -and $Top.Minor -eq -1) {
        $NextName = 'RoboCop 1.1'
    }
    elseif ($Top.Minor -lt 9) {
        $NextName = 'RoboCop {0}.{1}' -f $Top.Major, ($Top.Minor + 1)
    }
    else {
        $NextName = 'RoboCop {0}.0' -f ($Top.Major + 1)
    }
}

$Dest = Join-Path $Root $NextName
Set-Content -LiteralPath (Join-Path $env:TEMP 'ROBOCOP_NEXT_BACKUP_FOLDER.txt') -Value $Dest -Encoding ASCII
