README — CHECK_LONG_PATHS_SETTING.cmd

Purpose:
Check whether Windows long path support is enabled.

How to use:
Double-click:
CHECK_LONG_PATHS_SETTING.cmd

Good result:
LongPathsEnabled=1 OK

Warning result:
LongPathsEnabled=0 WARNING should be 1

If it is 0:
Open PowerShell as Administrator and run:

Set-ItemProperty -Path "HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem" -Name "LongPathsEnabled" -Type DWord -Value 1

Then restart Windows.

Safety:
Reads the setting only.
Does not change the setting.
