@echo off
mkdir "C:\RoboCop" >nul 2>nul
start "" "C:\RoboCop"
