@echo off
title Check Windows LongPathsEnabled
powershell -NoProfile -Command "$p='HKLM:\SYSTEM\CurrentControlSet\Control\FileSystem'; $v=(Get-ItemProperty -Path $p -Name LongPathsEnabled -ErrorAction SilentlyContinue).LongPathsEnabled; if ($v -eq 1) { 'LongPathsEnabled=1 OK' } elseif ($null -eq $v) { 'LongPathsEnabled is missing or unreadable' } else { 'LongPathsEnabled=' + $v + ' WARNING should be 1' }"
echo.
pause
