README — ROBOCOP_VERSION_SELECTOR.ps1

Purpose:
Pick the next RoboCop version folder.

It looks inside:
C:\RoboCop

Then chooses the next folder:

No versions -> RoboCop 1
RoboCop 1 -> RoboCop 1.1
RoboCop 1.1 -> RoboCop 1.2
...
RoboCop 1.9 -> RoboCop 2.0
RoboCop 2.0 -> RoboCop 2.1

Normal use:
Do not run this directly.
The backup tools call it for you.

Safety:
Creates C:\RoboCop if missing.
Writes a temp file that tells the backup tools where to copy.
Does not copy files by itself.
Does not delete, move, commit, or push.
