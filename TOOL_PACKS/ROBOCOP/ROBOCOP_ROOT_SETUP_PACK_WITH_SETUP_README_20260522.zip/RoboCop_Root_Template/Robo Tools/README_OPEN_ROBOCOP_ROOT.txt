README — OPEN_ROBOCOP_ROOT.cmd

Purpose:
Open:
C:\RoboCop

How to use:
Double-click:
OPEN_ROBOCOP_ROOT.cmd

What it does:
Creates C:\RoboCop if missing.
Opens C:\RoboCop in File Explorer.

Safety:
Does not copy files.
Does not delete files.
Does not move files.
Does not change Mr.Kleen.
