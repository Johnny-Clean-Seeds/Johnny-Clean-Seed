@echo off
setlocal EnableExtensions
title Setup RoboCop Root

set "SRC=%~dp0RoboCop_Root_Template"
set "ROOT=C:\RoboCop"

if not exist "%SRC%\" (
  echo TEMPLATE FOLDER NOT FOUND:
  echo %SRC%
  echo.
  echo Extract the ZIP first, then run this setup file again.
  echo.
  pause
  exit /b 1
)

mkdir "%ROOT%" >nul 2>nul
mkdir "%ROOT%\Back Tool" >nul 2>nul
mkdir "%ROOT%\Robo Tools" >nul 2>nul

xcopy "%SRC%\*" "%ROOT%\" /E /I /Y >nul

echo.
echo ROBOCOP ROOT SETUP COMPLETE
echo Root:
echo   %ROOT%
echo.
echo Tool folders:
echo   %ROOT%\Back Tool
echo   %ROOT%\Robo Tools
echo.
echo Version backups will be created as:
echo   C:\RoboCop\RoboCop 1
echo   C:\RoboCop\RoboCop 1.1
echo   C:\RoboCop\RoboCop 1.2
echo   ...
echo   C:\RoboCop\RoboCop 1.9
echo   C:\RoboCop\RoboCop 2.0
echo   C:\RoboCop\RoboCop 2.1
echo.
echo Open C:\RoboCop now.
start "" "%ROOT%"
echo.
pause
