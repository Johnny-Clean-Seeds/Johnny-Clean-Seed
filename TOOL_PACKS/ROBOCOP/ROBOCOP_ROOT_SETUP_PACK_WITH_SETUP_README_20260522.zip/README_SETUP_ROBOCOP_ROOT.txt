README — SETUP_ROBOCOP_ROOT.cmd

Purpose:
This is the installer button for the RoboCop root.

Why this file sits outside:
SETUP_ROBOCOP_ROOT.cmd is outside the RoboCop_Root_Template folder because it copies the template into the real C-drive root location.

It uses this source:
RoboCop_Root_Template

And builds this destination:
C:\RoboCop

What it creates:
C:\RoboCop
C:\RoboCop\Back Tool
C:\RoboCop\Robo Tools

After setup, backups will be created directly under:
C:\RoboCop

Version pattern:
C:\RoboCop\RoboCop 1
C:\RoboCop\RoboCop 1.1
C:\RoboCop\RoboCop 1.2
...
C:\RoboCop\RoboCop 1.9
C:\RoboCop\RoboCop 2.0
C:\RoboCop\RoboCop 2.1

How to use:
1. Extract the ZIP first.
2. Double-click SETUP_ROBOCOP_ROOT.cmd.
3. Let it create/open C:\RoboCop.
4. Use the tools inside C:\RoboCop after that.

What to do after setup:
Use:
C:\RoboCop\Back Tool\BACKUP_MR_KLEEN_TO_ROBOCOP.cmd

Or:
C:\RoboCop\Back Tool\DRAG_FOLDER_TO_ROBOCOP.cmd

Can I delete the extracted setup folder later?
Yes, after C:\RoboCop exists and looks right, the extracted ZIP/setup folder is just packaging.

Safety:
This setup creates folders and copies the RoboCop tool files into C:\RoboCop.
It does not back up Mr.Kleen by itself.
It does not delete project files.
It does not move project files.
It does not commit or push.
It does not rewrite doctrine, active guides, or CURRENT_TRUTH_INDEX.
