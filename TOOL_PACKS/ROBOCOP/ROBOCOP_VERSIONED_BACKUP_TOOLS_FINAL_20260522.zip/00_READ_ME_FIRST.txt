RoboCop Versioned Backup Tools — Final — 20260522

Backup root:
C:\RoboCop

Version folder pattern:
C:\RoboCop\RoboCop 1
C:\RoboCop\RoboCop 1.1
C:\RoboCop\RoboCop 1.2
...
C:\RoboCop\RoboCop 1.9
C:\RoboCop\RoboCop 2.0
C:\RoboCop\RoboCop 2.1
...

Each backup creates the next version after the highest existing RoboCop version folder.

Files:

1. BACKUP_MR_KLEEN_TO_ROBOCOP.cmd
   Double-click this to back up:
   C:\Users\<you>\Desktop\Jxhnny_Kleen_C3dz

2. DRAG_FOLDER_TO_ROBOCOP.cmd
   Drag any folder onto this file.
   It backs up the dragged folder into the next RoboCop version folder.

3. OPEN_ROBOCOP_ROOT.cmd
   Opens C:\RoboCop.

4. CHECK_LONG_PATHS_SETTING.cmd
   Shows whether Windows LongPathsEnabled is 1.

Robocopy success:
Exit codes 0 through 7 are treated as OK.
Exit code 8 or higher is failure.

Boundary:
These tools copy only. They do not delete, move, commit, push, rewrite, or promote project files.
