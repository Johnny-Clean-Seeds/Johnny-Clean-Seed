@echo off
setlocal EnableExtensions
title Backup Mr.Kleen to RoboCop

set "SRC=%USERPROFILE%\Desktop\Jxhnny_Kleen_C3dz"

if not exist "%SRC%\" (
  echo SOURCE NOT FOUND:
  echo %SRC%
  echo.
  pause
  exit /b 1
)

set "SELECTOR=%TEMP%\ROBOCOP_SELECT_NEXT_BACKUP_FOLDER.ps1"

> "%SELECTOR%" echo $ErrorActionPreference = 'Stop'
>> "%SELECTOR%" echo $Root = 'C:\RoboCop'
>> "%SELECTOR%" echo New-Item -ItemType Directory -Force -Path $Root ^| Out-Null
>> "%SELECTOR%" echo $Versions = @()
>> "%SELECTOR%" echo Get-ChildItem -LiteralPath $Root -Directory -ErrorAction SilentlyContinue ^| ForEach-Object {
>> "%SELECTOR%" echo     if ($_.Name -eq 'RoboCop 1') { $Versions += [pscustomobject]@{ Name = $_.Name; Major = 1; Minor = -1 } }
>> "%SELECTOR%" echo     elseif ($_.Name -match '^RoboCop (\d+)\.(\d+)$') { $Versions += [pscustomobject]@{ Name = $_.Name; Major = [int]$Matches[1]; Minor = [int]$Matches[2] } }
>> "%SELECTOR%" echo }
>> "%SELECTOR%" echo if ($Versions.Count -eq 0) { $NextName = 'RoboCop 1' } else {
>> "%SELECTOR%" echo     $Top = $Versions ^| Sort-Object Major, Minor -Descending ^| Select-Object -First 1
>> "%SELECTOR%" echo     if ($Top.Major -eq 1 -and $Top.Minor -eq -1) { $NextName = 'RoboCop 1.1' }
>> "%SELECTOR%" echo     elseif ($Top.Minor -lt 9) { $NextName = 'RoboCop {0}.{1}' -f $Top.Major, ($Top.Minor + 1) }
>> "%SELECTOR%" echo     else { $NextName = 'RoboCop {0}.0' -f ($Top.Major + 1) }
>> "%SELECTOR%" echo }
>> "%SELECTOR%" echo $Dest = Join-Path $Root $NextName
>> "%SELECTOR%" echo Set-Content -LiteralPath (Join-Path $env:TEMP 'ROBOCOP_NEXT_BACKUP_FOLDER.txt') -Value $Dest -Encoding ASCII

powershell -NoProfile -ExecutionPolicy Bypass -File "%SELECTOR%"

if errorlevel 1 (
  echo FAILED TO CHOOSE NEXT ROBOCOP VERSION FOLDER.
  echo.
  pause
  exit /b 1
)

set /p DST=<"%TEMP%\ROBOCOP_NEXT_BACKUP_FOLDER.txt"
mkdir "%DST%" >nul 2>nul

echo.
echo ROBOCOP BACKUP
echo Source:
echo   %SRC%
echo Destination:
echo   %DST%
echo.

robocopy "\\?\%SRC%" "\\?\%DST%" /E /COPY:DAT /DCOPY:DAT /R:1 /W:1 /XJ /MT:8 /TEE /LOG:"%DST%\ROBOCOPY_BACKUP_LOG.txt"

set "CODE=%ERRORLEVEL%"

echo.
if %CODE% LEQ 7 (
  echo BACKUP COPY OK
  echo Destination: %DST%
  echo Robocopy exit code: %CODE%
  echo Log: %DST%\ROBOCOPY_BACKUP_LOG.txt
) else (
  echo BACKUP FAILED
  echo Robocopy exit code: %CODE%
  echo Check log:
  echo %DST%\ROBOCOPY_BACKUP_LOG.txt
)

echo.
pause
exit /b %CODE%
