RoboCop Root — Read Me First

Root folder:
C:\RoboCop

Tool folders:
C:\RoboCop\Back Tool
C:\RoboCop\Robo Tools

Backup version folders are made directly under C:\RoboCop.

Version pattern:
C:\RoboCop\RoboCop 1
C:\RoboCop\RoboCop 1.1
C:\RoboCop\RoboCop 1.2
...
C:\RoboCop\RoboCop 1.9
C:\RoboCop\RoboCop 2.0
C:\RoboCop\RoboCop 2.1

Use:
C:\RoboCop\Back Tool\BACKUP_MR_KLEEN_TO_ROBOCOP.cmd
to back up the Mr.Kleen project.

Use:
C:\RoboCop\Back Tool\DRAG_FOLDER_TO_ROBOCOP.cmd
by dragging a folder onto it.

Safety:
These tools copy only.
They do not delete, move, commit, push, rewrite, or promote project files.
